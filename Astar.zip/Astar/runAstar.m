clc
map = load('AStarTestmap.txt');
start = [1 3];
qgoal = [10 7];
AStar_jcc329(start, qgoal, map)